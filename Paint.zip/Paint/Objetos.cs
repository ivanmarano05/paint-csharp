﻿using Painter_2._0.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Painter_2._0
{
    public partial class Objetos : Form
    {
        public Objetos()
        {
            InitializeComponent();
        }

        private void Objetos_Load(object sender, EventArgs e)
        {
            ln = (Lienzo)this.Owner;
        }

        Lienzo ln;

        public Lienzo Ln { get => ln; set => ln = value; }
    }
}
