﻿namespace Painter_2._0
{
    partial class Controles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Controles));
            this.boton_guardar = new System.Windows.Forms.Button();
            this.boton_borrar = new System.Windows.Forms.Button();
            this.boton_imagenes = new System.Windows.Forms.Button();
            this.boton_agregar_texto = new System.Windows.Forms.Button();
            this.boton_rectangulo = new System.Windows.Forms.Button();
            this.boton_circulo = new System.Windows.Forms.Button();
            this.boton_goma = new System.Windows.Forms.Button();
            this.boton_lapiz = new System.Windows.Forms.Button();
            this.boton_rellenar = new System.Windows.Forms.Button();
            this.boton_color = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.boton_editar_texto = new System.Windows.Forms.Button();
            this.textBoxGoma = new System.Windows.Forms.TextBox();
            this.textBoxLapiz = new System.Windows.Forms.TextBox();
            this.escribirTexto = new System.Windows.Forms.TextBox();
            this.labelTamañoLapiz = new System.Windows.Forms.Label();
            this.labelTamañoGoma = new System.Windows.Forms.Label();
            this.mostrar_color = new System.Windows.Forms.Button();
            this.boton_confirmar = new System.Windows.Forms.Button();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.elegir_color = new System.Windows.Forms.PictureBox();
            this.boton_linea = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elegir_color)).BeginInit();
            this.SuspendLayout();
            // 
            // boton_guardar
            // 
            this.boton_guardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_guardar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_guardar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_guardar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_guardar.ForeColor = System.Drawing.Color.White;
            this.boton_guardar.Location = new System.Drawing.Point(30, 654);
            this.boton_guardar.Name = "boton_guardar";
            this.boton_guardar.Size = new System.Drawing.Size(146, 30);
            this.boton_guardar.TabIndex = 23;
            this.boton_guardar.Text = "Guardar";
            this.boton_guardar.UseVisualStyleBackColor = true;
            this.boton_guardar.Click += new System.EventHandler(this.boton_guardar_Click);
            // 
            // boton_borrar
            // 
            this.boton_borrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_borrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_borrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_borrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_borrar.ForeColor = System.Drawing.Color.White;
            this.boton_borrar.Location = new System.Drawing.Point(30, 618);
            this.boton_borrar.Name = "boton_borrar";
            this.boton_borrar.Size = new System.Drawing.Size(146, 30);
            this.boton_borrar.TabIndex = 22;
            this.boton_borrar.Text = "Borrar";
            this.boton_borrar.UseVisualStyleBackColor = true;
            this.boton_borrar.Click += new System.EventHandler(this.boton_borrar_Click);
            // 
            // boton_imagenes
            // 
            this.boton_imagenes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_imagenes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_imagenes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_imagenes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_imagenes.ForeColor = System.Drawing.Color.White;
            this.boton_imagenes.Location = new System.Drawing.Point(6, 387);
            this.boton_imagenes.Name = "boton_imagenes";
            this.boton_imagenes.Size = new System.Drawing.Size(167, 45);
            this.boton_imagenes.TabIndex = 21;
            this.boton_imagenes.Text = "Imagenes";
            this.boton_imagenes.UseVisualStyleBackColor = true;
            this.boton_imagenes.Click += new System.EventHandler(this.boton_imagenes_Click);
            // 
            // boton_agregar_texto
            // 
            this.boton_agregar_texto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_agregar_texto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_agregar_texto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_agregar_texto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_agregar_texto.ForeColor = System.Drawing.Color.White;
            this.boton_agregar_texto.Location = new System.Drawing.Point(6, 332);
            this.boton_agregar_texto.Name = "boton_agregar_texto";
            this.boton_agregar_texto.Size = new System.Drawing.Size(83, 23);
            this.boton_agregar_texto.TabIndex = 20;
            this.boton_agregar_texto.Text = "Agregar Texto";
            this.boton_agregar_texto.UseVisualStyleBackColor = true;
            this.boton_agregar_texto.Click += new System.EventHandler(this.boton_agregar_texto_Click);
            // 
            // boton_rectangulo
            // 
            this.boton_rectangulo.AutoSize = true;
            this.boton_rectangulo.BackgroundImage = global::Painter_2._0.Properties.Resources.rectangle;
            this.boton_rectangulo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.boton_rectangulo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_rectangulo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_rectangulo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_rectangulo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_rectangulo.ForeColor = System.Drawing.Color.White;
            this.boton_rectangulo.Location = new System.Drawing.Point(120, 258);
            this.boton_rectangulo.Name = "boton_rectangulo";
            this.boton_rectangulo.Size = new System.Drawing.Size(52, 45);
            this.boton_rectangulo.TabIndex = 19;
            this.boton_rectangulo.UseVisualStyleBackColor = true;
            this.boton_rectangulo.Click += new System.EventHandler(this.boton_rectangulo_Click);
            // 
            // boton_circulo
            // 
            this.boton_circulo.BackgroundImage = global::Painter_2._0.Properties.Resources.circle;
            this.boton_circulo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.boton_circulo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_circulo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_circulo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_circulo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_circulo.ForeColor = System.Drawing.Color.White;
            this.boton_circulo.Location = new System.Drawing.Point(63, 258);
            this.boton_circulo.Name = "boton_circulo";
            this.boton_circulo.Size = new System.Drawing.Size(52, 45);
            this.boton_circulo.TabIndex = 18;
            this.boton_circulo.UseVisualStyleBackColor = true;
            this.boton_circulo.Click += new System.EventHandler(this.boton_circulo_Click);
            // 
            // boton_goma
            // 
            this.boton_goma.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_goma.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_goma.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_goma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_goma.ForeColor = System.Drawing.Color.White;
            this.boton_goma.Location = new System.Drawing.Point(6, 175);
            this.boton_goma.Name = "boton_goma";
            this.boton_goma.Size = new System.Drawing.Size(167, 30);
            this.boton_goma.TabIndex = 16;
            this.boton_goma.Text = "Goma";
            this.boton_goma.UseVisualStyleBackColor = true;
            this.boton_goma.Click += new System.EventHandler(this.boton_goma_Click);
            // 
            // boton_lapiz
            // 
            this.boton_lapiz.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_lapiz.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_lapiz.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_lapiz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_lapiz.ForeColor = System.Drawing.Color.White;
            this.boton_lapiz.Location = new System.Drawing.Point(6, 113);
            this.boton_lapiz.Name = "boton_lapiz";
            this.boton_lapiz.Size = new System.Drawing.Size(167, 30);
            this.boton_lapiz.TabIndex = 15;
            this.boton_lapiz.Text = "Lapiz";
            this.boton_lapiz.UseVisualStyleBackColor = true;
            this.boton_lapiz.Click += new System.EventHandler(this.boton_lapiz_Click);
            // 
            // boton_rellenar
            // 
            this.boton_rellenar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_rellenar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_rellenar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_rellenar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_rellenar.ForeColor = System.Drawing.Color.White;
            this.boton_rellenar.Location = new System.Drawing.Point(6, 59);
            this.boton_rellenar.Name = "boton_rellenar";
            this.boton_rellenar.Size = new System.Drawing.Size(167, 45);
            this.boton_rellenar.TabIndex = 14;
            this.boton_rellenar.Text = "Rellenar";
            this.boton_rellenar.UseVisualStyleBackColor = true;
            this.boton_rellenar.Click += new System.EventHandler(this.boton_rellenar_Click);
            // 
            // boton_color
            // 
            this.boton_color.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_color.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_color.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_color.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_color.ForeColor = System.Drawing.Color.White;
            this.boton_color.Location = new System.Drawing.Point(6, 8);
            this.boton_color.Name = "boton_color";
            this.boton_color.Size = new System.Drawing.Size(167, 45);
            this.boton_color.TabIndex = 13;
            this.boton_color.Text = "              Color:";
            this.boton_color.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.boton_color.UseVisualStyleBackColor = true;
            this.boton_color.Click += new System.EventHandler(this.boton_color_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.trackBar1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.mostrar_color);
            this.panel1.Controls.Add(this.boton_editar_texto);
            this.panel1.Controls.Add(this.textBoxGoma);
            this.panel1.Controls.Add(this.textBoxLapiz);
            this.panel1.Controls.Add(this.escribirTexto);
            this.panel1.Controls.Add(this.boton_imagenes);
            this.panel1.Controls.Add(this.boton_agregar_texto);
            this.panel1.Controls.Add(this.boton_rectangulo);
            this.panel1.Controls.Add(this.boton_circulo);
            this.panel1.Controls.Add(this.boton_linea);
            this.panel1.Controls.Add(this.boton_goma);
            this.panel1.Controls.Add(this.boton_lapiz);
            this.panel1.Controls.Add(this.boton_rellenar);
            this.panel1.Controls.Add(this.boton_color);
            this.panel1.Controls.Add(this.labelTamañoLapiz);
            this.panel1.Controls.Add(this.labelTamañoGoma);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(12, 112);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(178, 464);
            this.panel1.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(28, 232);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 23);
            this.label2.TabIndex = 29;
            this.label2.Text = "Figuras";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(28, 306);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 23);
            this.label1.TabIndex = 28;
            this.label1.Text = "Texto";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // boton_editar_texto
            // 
            this.boton_editar_texto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_editar_texto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_editar_texto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_editar_texto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_editar_texto.ForeColor = System.Drawing.Color.White;
            this.boton_editar_texto.Location = new System.Drawing.Point(92, 332);
            this.boton_editar_texto.Name = "boton_editar_texto";
            this.boton_editar_texto.Size = new System.Drawing.Size(81, 23);
            this.boton_editar_texto.TabIndex = 27;
            this.boton_editar_texto.Text = "Editar";
            this.boton_editar_texto.UseVisualStyleBackColor = true;
            this.boton_editar_texto.Click += new System.EventHandler(this.boton_editar_texto_Click);
            // 
            // textBoxGoma
            // 
            this.textBoxGoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxGoma.Location = new System.Drawing.Point(118, 211);
            this.textBoxGoma.Name = "textBoxGoma";
            this.textBoxGoma.Size = new System.Drawing.Size(55, 21);
            this.textBoxGoma.TabIndex = 24;
            this.textBoxGoma.Text = "10";
            this.textBoxGoma.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxGoma.TextChanged += new System.EventHandler(this.textBoxGoma_TextChanged);
            this.textBoxGoma.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxGoma_KeyPress);
            // 
            // textBoxLapiz
            // 
            this.textBoxLapiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLapiz.Location = new System.Drawing.Point(118, 149);
            this.textBoxLapiz.Name = "textBoxLapiz";
            this.textBoxLapiz.Size = new System.Drawing.Size(55, 21);
            this.textBoxLapiz.TabIndex = 23;
            this.textBoxLapiz.Text = "1";
            this.textBoxLapiz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxLapiz.TextChanged += new System.EventHandler(this.textBoxLapiz_TextChanged);
            this.textBoxLapiz.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxLapiz_KeyPress);
            // 
            // escribirTexto
            // 
            this.escribirTexto.Location = new System.Drawing.Point(6, 361);
            this.escribirTexto.Name = "escribirTexto";
            this.escribirTexto.Size = new System.Drawing.Size(167, 20);
            this.escribirTexto.TabIndex = 22;
            // 
            // labelTamañoLapiz
            // 
            this.labelTamañoLapiz.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTamañoLapiz.ForeColor = System.Drawing.Color.White;
            this.labelTamañoLapiz.Location = new System.Drawing.Point(6, 147);
            this.labelTamañoLapiz.Name = "labelTamañoLapiz";
            this.labelTamañoLapiz.Size = new System.Drawing.Size(126, 23);
            this.labelTamañoLapiz.TabIndex = 25;
            this.labelTamañoLapiz.Text = "Tamaño:";
            this.labelTamañoLapiz.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTamañoGoma
            // 
            this.labelTamañoGoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTamañoGoma.ForeColor = System.Drawing.Color.White;
            this.labelTamañoGoma.Location = new System.Drawing.Point(6, 209);
            this.labelTamañoGoma.Name = "labelTamañoGoma";
            this.labelTamañoGoma.Size = new System.Drawing.Size(126, 23);
            this.labelTamañoGoma.TabIndex = 26;
            this.labelTamañoGoma.Text = "Tamaño:";
            this.labelTamañoGoma.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mostrar_color
            // 
            this.mostrar_color.BackColor = System.Drawing.Color.White;
            this.mostrar_color.Location = new System.Drawing.Point(118, 17);
            this.mostrar_color.Name = "mostrar_color";
            this.mostrar_color.Size = new System.Drawing.Size(31, 26);
            this.mostrar_color.TabIndex = 26;
            this.mostrar_color.UseVisualStyleBackColor = false;
            // 
            // boton_confirmar
            // 
            this.boton_confirmar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_confirmar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_confirmar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_confirmar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_confirmar.ForeColor = System.Drawing.Color.White;
            this.boton_confirmar.Location = new System.Drawing.Point(30, 582);
            this.boton_confirmar.Name = "boton_confirmar";
            this.boton_confirmar.Size = new System.Drawing.Size(146, 30);
            this.boton_confirmar.TabIndex = 31;
            this.boton_confirmar.Text = "Confirmar texto/imagen";
            this.boton_confirmar.UseVisualStyleBackColor = true;
            this.boton_confirmar.Click += new System.EventHandler(this.boton_confirmar_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.AutoSize = false;
            this.trackBar1.BackColor = System.Drawing.Color.Black;
            this.trackBar1.Location = new System.Drawing.Point(92, 438);
            this.trackBar1.Maximum = 500;
            this.trackBar1.Minimum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(80, 20);
            this.trackBar1.TabIndex = 32;
            this.trackBar1.TickFrequency = 100;
            this.trackBar1.Value = 300;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(6, 435);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 23);
            this.label3.TabIndex = 33;
            this.label3.Text = "Tamaño:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // elegir_color
            // 
            this.elegir_color.Cursor = System.Windows.Forms.Cursors.Hand;
            this.elegir_color.Image = global::Painter_2._0.Properties.Resources.paleta;
            this.elegir_color.Location = new System.Drawing.Point(-3, -2);
            this.elegir_color.Name = "elegir_color";
            this.elegir_color.Size = new System.Drawing.Size(204, 108);
            this.elegir_color.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.elegir_color.TabIndex = 25;
            this.elegir_color.TabStop = false;
            this.elegir_color.MouseClick += new System.Windows.Forms.MouseEventHandler(this.elegir_color_MouseClick);
            // 
            // boton_linea
            // 
            this.boton_linea.BackgroundImage = global::Painter_2._0.Properties.Resources.line;
            this.boton_linea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.boton_linea.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boton_linea.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Navy;
            this.boton_linea.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.boton_linea.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.boton_linea.ForeColor = System.Drawing.Color.White;
            this.boton_linea.Location = new System.Drawing.Point(5, 258);
            this.boton_linea.Name = "boton_linea";
            this.boton_linea.Size = new System.Drawing.Size(52, 45);
            this.boton_linea.TabIndex = 17;
            this.boton_linea.UseVisualStyleBackColor = true;
            this.boton_linea.Click += new System.EventHandler(this.boton_linea_Click);
            // 
            // Controles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GrayText;
            this.ClientSize = new System.Drawing.Size(200, 692);
            this.Controls.Add(this.boton_confirmar);
            this.Controls.Add(this.elegir_color);
            this.Controls.Add(this.boton_guardar);
            this.Controls.Add(this.boton_borrar);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(50, 25);
            this.Name = "Controles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Controles";
            this.Load += new System.EventHandler(this.Controles_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elegir_color)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox elegir_color;
        public System.Windows.Forms.Button boton_guardar;
        public System.Windows.Forms.Button boton_borrar;
        public System.Windows.Forms.Button boton_imagenes;
        public System.Windows.Forms.Button boton_agregar_texto;
        public System.Windows.Forms.Button boton_rectangulo;
        public System.Windows.Forms.Button boton_circulo;
        public System.Windows.Forms.Button boton_linea;
        public System.Windows.Forms.Button boton_goma;
        public System.Windows.Forms.Button boton_lapiz;
        public System.Windows.Forms.Button boton_rellenar;
        public System.Windows.Forms.Button boton_color;
        public System.Windows.Forms.Button mostrar_color;
        public System.Windows.Forms.TextBox escribirTexto;
        public System.Windows.Forms.Label labelTamañoGoma;
        public System.Windows.Forms.Label labelTamañoLapiz;
        public System.Windows.Forms.TextBox textBoxGoma;
        public System.Windows.Forms.TextBox textBoxLapiz;
        public System.Windows.Forms.Button boton_editar_texto;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Button boton_confirmar;
        public System.Windows.Forms.TrackBar trackBar1;
        public System.Windows.Forms.Label label3;
    }
}