﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Painter_2._0.Clases;

namespace Painter_2._0.Clases
{
    internal class Elipse : Objeto
    {
        string nombre;
        float cx, cy, sx, sy;
        static int cont = 1;
        public float Cx { get => cx; set => cx = value; }
        public float Cy { get => cy; set => cy = value; }
        public float Sx { get => sx; set => sx = value; }
        public float Sy { get => sy; set => sy = value; }
        public string NombreReal { get => nombre; set => nombre = value; }

        public Elipse(string nombre)
            :base(nombre)
        {

        }

        public Elipse(string nombre, float cx, float cy, float sx, float sy)
            :base(nombre)
        {
            this.nombre = "Circulo" + cont;
            cont++;

            this.cx = cx;
            this.cy = cy;
            this.sx = sx;
            this.sy = sy;
        }

        public override void dibujar(Graphics dibujo, Pen lapiz)
        {
            dibujo.DrawEllipse(lapiz, this.cx, this.cy, this.sx, this.sy);
        }

        public static void reiniciarContador()
        {
            cont = 1;
        }

        public override string ToString()
        {
            return nombre;
        }
    }
}
