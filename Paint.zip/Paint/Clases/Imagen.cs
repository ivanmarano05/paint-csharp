﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Painter_2._0.Clases
{
    public class Imagen: Objeto
    {
        Point posicion;
        float limiteX, limiteY;
        static int cont = 1;
        string nombre;
        Bitmap bmp;

        public string NombreReal { get => nombre; set => nombre = value; }
        public Point Posicion { get => posicion; set => posicion = value; }
        public Bitmap Bmp { get => bmp; set => bmp = value; }
        public float LimiteX { get => limiteX; set => limiteX = value; }
        public float LimiteY { get => limiteY; set => limiteY = value; }

        public Imagen(string nombre, Bitmap bmp, Point posicion, Point limite)
            : base(nombre)
        {
            this.nombre = "Imagen"+cont;
            cont++;
            this.bmp = bmp;
            this.posicion = posicion;
            this.limiteX = limite.X;
            this.limiteY = limite.Y;
        }

        public static void reiniciarContador()
        {
            cont = 1;
        }

        public override string ToString()
        {
            return nombre;
        }

        public override void dibujar(Graphics dibujo, Pen lapiz)
        {
            dibujo.DrawImage(bmp, this.posicion.X, this.posicion.Y, this.limiteX, this.limiteY);
        }

        public void mover(Point e, Point pnt)
        {
            this.Posicion = new Point(this.Posicion.X + e.X - pnt.X, this.Posicion.Y + e.Y - pnt.Y);
        }
    }
}
