﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Painter_2._0.Clases
{
    public class Rectangulo : Objeto
    {
        string nombre;
        float cx, cy, ancho, alto;
        static int cont = 1;

        public string NombreReal { get => nombre; set => nombre = value; }
        public float Cx { get => cx; set => cx = value; }
        public float Cy { get => cy; set => cy = value; }
        public float Ancho { get => ancho; set => ancho = value; }
        public float Alto { get => alto; set => alto = value; }

        public Rectangulo(string nombre)
            : base(nombre)
        {

        }

        public Rectangulo(string nombre, float cx, float cy, float ancho, float alto)
            : base(nombre)
        {
            this.nombre = "Rectangulo" + cont;
            cont++;

            this.cx = cx;
            this.cy = cy;
            this.ancho = ancho;
            this.alto = alto;
        }

        public override void dibujar(Graphics dibujo, Pen lapiz)
        {
            dibujo.DrawRectangle(lapiz, this.cx, this.cy, this.ancho, this.alto);
        }

        public static void reiniciarContador()
        {
            cont = 1;
        }

        public override string ToString()
        {
            return nombre;
        }
    }
}
