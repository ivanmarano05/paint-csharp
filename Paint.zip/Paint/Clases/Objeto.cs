﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Painter_2._0.Clases
{
    public abstract class Objeto
    {
        string nombre;

        public string Nombre { get => nombre; set => nombre = value; }

        public Objeto(string nombre)
        {
            this.nombre = nombre;
        }

        public abstract void dibujar(Graphics dibujo, Pen lapiz);
    }
}
