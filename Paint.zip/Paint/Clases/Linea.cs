﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Painter_2._0.Clases;

namespace Painter_2._0.Clases
{
    public class Linea : Objeto
    {
        string nombre;
        float cx, cy, x, y;
        static int cont = 1;

        public string NombreReal { get => nombre; set => nombre = value; }
        public float Cx { get => cx; set => cx = value; }
        public float Cy { get => cy; set => cy = value; }
        public float X { get => x; set => x = value; }
        public float Y { get => y; set => y = value; }

        public Linea(string nombre)
            : base(nombre)
        {

        }

        public Linea(string nombre, float cx, float cy, float x, float y)
            : base(nombre)
        {
            this.nombre = "Linea" + cont;
            cont++;

            this.cx = cx;
            this.cy = cy;
            this.x = x;
            this.y = y;
        }

        public override void dibujar(Graphics dibujo, Pen lapiz)
        {
            dibujo.DrawLine(lapiz, this.cx, this.cy, this.x, this.y);
        }

        public static void reiniciarContador()
        {
            cont = 1;
        }

        public override string ToString()
        {
            return nombre;
        }        
    }
}
