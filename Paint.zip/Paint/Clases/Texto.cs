﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Painter_2._0.Clases
{
    public class Texto: Objeto
    {
        Point posicion;
        static int cont = 1;
        string nombre, texto;
        Font fuente = new Font("Arial", 15);

        public string NombreReal { get => nombre; set => nombre = value; }
        public Point Posicion { get => posicion; set => posicion = value; }
        public string Textoo { get => texto; set => texto = value; }
        public Font Fuente { get => fuente; set => fuente = value; }

        public Texto(string nombre, string texto, Font fuente, Point posicion)
            : base(nombre)
        {
            this.nombre = "Texto" + cont;
            cont++;
            this.texto = texto;
            this.fuente = fuente;
            this.posicion = posicion;
        }

        public static void reiniciarContador()
        {
            cont = 1;
        }

        public override string ToString()
        {
            return nombre;
        }

        public override void dibujar(Graphics dibujo, Pen lapiz)
        {
            dibujo.DrawString(this.texto, this.fuente, Brushes.Black, this.Posicion);
        }

        public void mover(Point e, Point pnt)
        {
            this.Posicion = new Point(this.Posicion.X + e.X - pnt.X, this.Posicion.Y + e.Y - pnt.Y);
        }
    }
}
