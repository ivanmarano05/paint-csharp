﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Painter_2._0
{
    public partial class Controles : Form
    {
        public Controles()
        {
            InitializeComponent();            
        }

        private void Controles_Load(object sender, EventArgs e)
        {
            ln = (Lienzo)this.Owner;
        }

        Lienzo ln;
        string selector = null;

        ColorDialog cd = new ColorDialog();
        Color color_actual = Color.Black;
        Int32 tamanioLapiz = 1, tamanioGoma = 10;

        public string Selector { get => selector; set => selector = value; }

        private void boton_lapiz_Click(object sender, EventArgs e)
        {
            this.selector = "lapiz";
        }
        private void boton_goma_Click(object sender, EventArgs e)
        {
            this.selector = "goma";
        }

        private void boton_linea_Click(object sender, EventArgs e)
        {
            this.selector = "linea";
        }

        private void boton_circulo_Click(object sender, EventArgs e)
        {
            this.selector = "circulo";
        }

        private void boton_rellenar_Click(object sender, EventArgs e)
        {
            this.selector = "rellenar";
        }

        private void boton_rectangulo_Click(object sender, EventArgs e)
        {
            this.selector = "rectangulo";
        }

        private void boton_guardar_Click(object sender, EventArgs e)
        {
            this.selector = "imagenes";
            ln.guardarImagen();
        }

        private void boton_borrar_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("¿Seguro que desea borrar?", "Borrar", MessageBoxButtons.YesNo);

            if (dr == DialogResult.Yes)
            {
                this.selector = null;
                ln.borrarDibujo();
            }                       
        }

        private void elegir_color_MouseClick(object sender, MouseEventArgs e)
        {
            Point p = obtenerPunto(elegir_color, e.Location);
            mostrar_color.BackColor = ((Bitmap)elegir_color.Image).GetPixel(p.X, p.Y);
            color_actual = mostrar_color.BackColor;
            ln.Color_nuevo = color_actual;
            Pen lap = new Pen(color_actual, tamanioLapiz);
            ln.Lapiz = lap;
        }
        private Point obtenerPunto(PictureBox pb, Point punto)
        {
            double px = 1d * pb.Image.Width / pb.Width;
            double py = 1d * pb.Image.Height / pb.Height;
            return new Point((int)(punto.X * px), (int)(punto.Y * py));
        }

        private void boton_imagenes_Click(object sender, EventArgs e)
        {
            this.selector = "imagenes";
            ln.abrirImagen();
        }

        private void boton_color_Click(object sender, EventArgs e)
        {
            cd.ShowDialog();
            color_actual = cd.Color;
            mostrar_color.BackColor = cd.Color;
            ln.Color_nuevo = color_actual;
            Pen lap = new Pen(color_actual, tamanioLapiz);
            ln.Lapiz = lap;
        }

        private void textBoxLapiz_TextChanged(object sender, EventArgs e)
        {
            tamanioLapiz = Int32.Parse(textBoxLapiz.Text);
            Pen lap = new Pen(color_actual, tamanioLapiz);
            ln.Lapiz = lap;
        }

        private void textBoxGoma_TextChanged(object sender, EventArgs e)
        {
            tamanioGoma = Int32.Parse(textBoxGoma.Text);
            Pen goma = new Pen(Color.White, tamanioGoma);
            ln.Goma = goma;
        }

        private void textBoxLapiz_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void textBoxGoma_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsNumber(e.KeyChar)))
            {
                e.Handled = true;
            }
        }        

        private void boton_agregar_texto_Click(object sender, EventArgs e)
        {
            this.selector = "texto";
            ln.agregarTexto(null);
        }

        private void boton_editar_texto_Click(object sender, EventArgs e)
        {
            this.selector = "texto";
            ln.editarTexto();
        }

        private void boton_confirmar_Click(object sender, EventArgs e)
        {
            ln.confirmarDibujo();
        }

    }
}
