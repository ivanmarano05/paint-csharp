﻿using Painter_2._0.Clases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Painter_2._0
{
    public partial class Lienzo : Form
    {
        public Lienzo()
        {
            InitializeComponent();

            bm = new Bitmap(picBoxMain.Width, picBoxMain.Height);
            dibujo = Graphics.FromImage(bm);
            dibujo.Clear(Color.White);
            picBoxMain.Image = bm;
        }

        private void Lienzo_Load(object sender, EventArgs e)
        {
            ctrls.Owner = this;
            ctrls.Show();
            objs.Owner = this;
            objs.Show();
        }

        Controles ctrls = new Controles();
        Objetos objs = new Objetos();

        Bitmap bm;
        Graphics dibujo;
        bool pintar = false;
        Point px, py, pnt;
        Color color_nuevo;
        int x, y, sx, sy, cx, cy, limiteX, limiteY;
        Pen lapiz = new Pen(Color.Black, 1);
        Pen goma = new Pen(Color.White, 10);
        Imagen img;
        Texto text;
        string texto;
        Font fuente = new Font("Arial", 15);

        List<Objeto> listObj = new List<Objeto>();

        public Color Color_nuevo { get => color_nuevo; set => color_nuevo = value; }
        public Pen Lapiz { get => lapiz; set => lapiz = value; }
        public Pen Goma { get => goma; set => goma = value; }
        public List<Objeto> ListObj { get => listObj; set => listObj = value; }        

        private void picBoxMain_MouseDown(object sender, MouseEventArgs e)
        {
            pintar = true;
            py = e.Location;

            cx = e.X;
            cy = e.Y;

            pnt = e.Location;

            picBoxMain.Refresh();
        }

        private void picBoxMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (ctrls.Selector == "imagenes" && img != null)
            {
                img.LimiteX = ctrls.trackBar1.Value;
                img.LimiteY = ctrls.trackBar1.Value;
                this.Invalidate();
            }

            if (pintar)
            {
                if (ctrls.Selector == "texto")
                {
                    text.mover(e.Location, pnt);
                    pnt = e.Location;
                    this.Invalidate();
                }
                if (ctrls.Selector == "imagenes" && img != null)
                {                    
                    img.mover(e.Location, pnt);
                    pnt = e.Location;
                    this.Invalidate();
                }
                if (ctrls.Selector == "lapiz")
                {
                    px = e.Location;
                    dibujo.DrawLine(lapiz, px, py);
                    py = px;
                }
                if (ctrls.Selector == "goma")
                {
                    px = e.Location;
                    dibujo.DrawLine(goma, px, py);
                    py = px;
                }
            }
            
            picBoxMain.Refresh();

            x = e.X;
            y = e.Y;
            sx = e.X - cx;
            sy = e.Y - cy;
        }

        private void picBoxMain_MouseUp(object sender, MouseEventArgs e)
        {
            pintar = false;

            sx = x - cx;
            sy = y - cy;

            if (ctrls.Selector == "circulo")
            {
                Elipse circulo = new Elipse(null, cx, cy, sx, sy);
                circulo.dibujar(dibujo, lapiz);
                listObj.Add(circulo);
                objs.listBox1.DataSource = null;
                objs.listBox1.DataSource = ListObj;
                objs.listBox1.DisplayMember = "NombreReal";
            }
            if (ctrls.Selector == "rectangulo")
            {
                Rectangulo rectangulo = new Rectangulo(null, cx, cy, sx, sy);
                rectangulo.dibujar(dibujo, lapiz);
                listObj.Add(rectangulo);
                objs.listBox1.DataSource = null;
                objs.listBox1.DataSource = ListObj;
                objs.listBox1.DisplayMember = "NombreReal";
            }
            if (ctrls.Selector == "linea")
            {
                Linea linea = new Linea(null, cx, cy, x, y);
                linea.dibujar(dibujo, lapiz);
                listObj.Add(linea);         
                objs.listBox1.DataSource = null;
                objs.listBox1.DataSource = ListObj;
                objs.listBox1.DisplayMember = "NombreReal";
            }
        }

        private void picBoxMain_Paint(object sender, PaintEventArgs e)
        {
            Graphics dibujo = e.Graphics;

            if (img != null)
            {
                img.dibujar(dibujo, lapiz);
            }

            if (text != null)
            {
                text.dibujar(dibujo, lapiz);
            }

            if (pintar)
            {
                if (ctrls.Selector == "circulo")
                {
                    dibujo.DrawEllipse(lapiz, cx, cy, sx, sy);
                }
                if (ctrls.Selector == "rectangulo")
                {
                    dibujo.DrawRectangle(lapiz, cx, cy, sx, sy);
                }
                if (ctrls.Selector == "linea")
                {
                    dibujo.DrawLine(lapiz, cx, cy, x, y);
                }
            }            
        }

        public void borrarDibujo()
        {
            dibujo.Clear(Color.White);
            listObj.Clear();
            objs.listBox1.DataSource = null;            
            picBoxMain.Image = bm;
            Elipse.reiniciarContador();
            Rectangulo.reiniciarContador();
            Linea.reiniciarContador();
            Imagen.reiniciarContador();
            Texto.reiniciarContador();
            text = null;
            img = null;
        }

        public void abrirImagen()
        {
            DialogResult dr = openFileDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                limiteX = ctrls.trackBar1.Value;
                limiteY = ctrls.trackBar1.Value;
                img = new Imagen(null, new Bitmap(openFileDialog1.FileName), new Point(100, 100), new Point(limiteX, limiteY));
            }
        }

        public void guardarImagen()
        {
            saveFileDialog1.Filter = "Image(*.jpg)|*.jpg|(*.*|*.*)";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Bitmap btm = bm.Clone(new Rectangle(0, 0, picBoxMain.Width, picBoxMain.Height), bm.PixelFormat);
                btm.Save(saveFileDialog1.FileName, ImageFormat.Jpeg);
            }

            ctrls.Selector = null;
        }

        public void agregarTexto(Font fuente)
        {
            if(fuente == null)
            {
                fuente = new Font("Arial", 15);
            }
            texto = ctrls.escribirTexto.Text;
            text = new Texto(null, texto, fuente, new Point(100, 100));
        }

        public void editarTexto()
        {
            DialogResult dr = fontDialog1.ShowDialog();
            if (dr == DialogResult.OK)
            {
                fuente = fontDialog1.Font;
                this.agregarTexto(fuente);
            }            
        }

        public void confirmarDibujo()
        {
            if(ctrls.Selector == "texto")
            {
                dibujo.DrawString(text.Textoo, text.Fuente, Brushes.Black, text.Posicion);
                listObj.Add(text);
                objs.listBox1.DataSource = null;
                objs.listBox1.DataSource = ListObj;
                objs.listBox1.DisplayMember = "NombreReal";
                ctrls.Selector = null;
            }
            else if (ctrls.Selector == "imagenes")
            {
                dibujo.DrawImage(img.Bmp, img.Posicion.X, img.Posicion.Y, img.LimiteX, img.LimiteY);
                listObj.Add(img);
                objs.listBox1.DataSource = null;
                objs.listBox1.DataSource = ListObj;
                objs.listBox1.DisplayMember = "NombreReal";
                img = null;
                ctrls.Selector = null;
            }
        }

        private void picBoxMain_MouseClick(object sender, MouseEventArgs e)
        {
            if (ctrls.Selector == "rellenar")
            {
                Point punto = obtenerPunto(picBoxMain, e.Location);
                rellenar(bm, punto.X, punto.Y, color_nuevo);
            }
        }

        private Point obtenerPunto(PictureBox pb, Point punto)
        {
            double px = 1d * pb.Image.Width / pb.Width;
            double py = 1d * pb.Image.Height / pb.Height;
            return new Point((int)(punto.X * px), (int)(punto.Y * py));
        }

        private void validar(Bitmap bm, Stack<Point> puntos, int x, int y, Color color_viejo, Color color_nuevo)
        {
            Color colorX = bm.GetPixel(x, y);
            if (colorX == color_viejo)
            {
                puntos.Push(new Point(x, y));
                bm.SetPixel(x, y, color_nuevo);
            }
        }

        public void rellenar(Bitmap bm, int x, int y, Color color_nuevo)
        {
            Color color_viejo = bm.GetPixel(x, y);
            Stack<Point> pixeles = new Stack<Point>();
            pixeles.Push(new Point(x, y));
            bm.SetPixel(x, y, color_nuevo);
            if (color_viejo == color_nuevo)
            {
                return;
            }

            while (pixeles.Count > 0)
            {
                Point pixel = (Point)pixeles.Pop();
                if (pixel.X > 0 && pixel.Y > 0 && pixel.X < bm.Width - 1 && pixel.Y < bm.Height - 1)
                {
                    validar(bm, pixeles, pixel.X - 1, pixel.Y, color_viejo, color_nuevo);
                    validar(bm, pixeles, pixel.X, pixel.Y - 1, color_viejo, color_nuevo);
                    validar(bm, pixeles, pixel.X + 1, pixel.Y, color_viejo, color_nuevo);
                    validar(bm, pixeles, pixel.X, pixel.Y + 1, color_viejo, color_nuevo);
                }
            }
        }
    }
}
